const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const cors = require('cors');
const morgan = require('morgan');
const { v4: uuidv4 } = require('uuid');

const app = express();
const root = path.resolve(__dirname, '..');
const dataDir = path.join(__dirname, 'data');
const visitorsFile = path.join(dataDir, 'visitors.json');
const commentsFile = path.join(dataDir, 'comments.json');
const configFile = path.join(dataDir, 'config.json');

app.use(morgan('dev'));
app.use(cors());
app.use(express.json());
// Serve site static files from project root
app.use(express.static(root));

async function readJson(file, fallback) {
  try {
    const raw = await fs.readFile(file, 'utf8');
    return JSON.parse(raw || 'null') || fallback;
  } catch (e) {
    return fallback;
  }
}
async function writeJson(file, obj) {
  await fs.writeFile(file, JSON.stringify(obj, null, 2), 'utf8');
}

// Visitor endpoints
app.post('/api/visitor', async (req, res) => {
  try {
    const body = req.body || {};
    const ip = req.headers['x-forwarded-for'] || req.ip || req.connection.remoteAddress || 'unknown';
    const ua = req.get('user-agent') || '';
    const entry = {
      id: uuidv4(),
      ts: new Date().toISOString(),
      name: body.name || '访客',
      identity: body.identity || 'personal',
      ip,
      ua,
      referrer: body.referrer || ''
    };
    const log = await readJson(visitorsFile, []);
    log.push(entry);
    // keep last 5000 entries if needed
    if (log.length > 5000) log.splice(0, log.length - 5000);
    await writeJson(visitorsFile, log);
    res.status(201).json({ ok: true, entry });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get('/api/visitors', async (req, res) => {
  try {
    const log = await readJson(visitorsFile, []);
    res.json(log);
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.delete('/api/visitors', async (req, res) => {
  try {
    await writeJson(visitorsFile, []);
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get('/api/visitors/export', async (req, res) => {
  try {
    res.download(visitorsFile, 'visitors.json');
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// Admin config
app.get('/api/admin/config', async (req, res) => {
  try {
    const cfg = await readJson(configFile, {});
    res.json(cfg);
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post('/api/admin/config', async (req, res) => {
  try {
    const payload = req.body || {};
    let cfg = await readJson(configFile, {});
    if (payload.section && Object.prototype.hasOwnProperty.call(payload, 'data')) {
      cfg[payload.section] = payload.data;
    } else if (typeof payload === 'object') {
      // replace by full config
      cfg = payload;
    }
    await writeJson(configFile, cfg);
    res.json({ ok: true, cfg });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// Comments: user submits -> pending; admin lists and publishes/deletes
app.post('/api/comments', async (req, res) => {
  try {
    const body = req.body || {};
    const ip = req.headers['x-forwarded-for'] || req.ip || req.connection.remoteAddress || 'unknown';
    const ua = req.get('user-agent') || '';
    const entry = {
      id: uuidv4(),
      ts: new Date().toISOString(),
      name: body.name || '匿名',
      content: body.content || '',
      status: 'pending', // pending | published
      ip,
      ua,
      referrer: body.referrer || ''
    };
    const list = await readJson(commentsFile, []);
    list.push(entry);
    await writeJson(commentsFile, list);
    res.status(201).json({ ok: true, entry });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get('/api/comments', async (req, res) => {
  try {
    const status = req.query.status; // optional filter
    const list = await readJson(commentsFile, []);
    if (status) {
      res.json(list.filter(c => c.status === status));
    } else {
      res.json(list);
    }
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.patch('/api/comments/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body || {};
    const list = await readJson(commentsFile, []);
    const idx = list.findIndex(c => c.id === id);
    if (idx === -1) return res.status(404).json({ ok: false, error: 'not found' });
    list[idx] = { ...list[idx], ...body };
    await writeJson(commentsFile, list);
    res.json({ ok: true, entry: list[idx] });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.delete('/api/comments/:id', async (req, res) => {
  try {
    const id = req.params.id;
    let list = await readJson(commentsFile, []);
    list = list.filter(c => c.id !== id);
    await writeJson(commentsFile, list);
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post('/api/comments/bulk-delete', async (req, res) => {
  try {
    const ids = req.body.ids || [];
    let list = await readJson(commentsFile, []);
    list = list.filter(c => !ids.includes(c.id));
    await writeJson(commentsFile, list);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// simple endpoint to check server
app.get('/api/health', (req, res) => res.json({ ok: true }));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server listening on http://localhost:${port}`));