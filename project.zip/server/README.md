# Nitrate_Zero - Backend Prototype

This is a minimal Node/Express prototype for the site used for development and testing.

Features:
- Serve static site from project root
- Visitor endpoints:
  - POST /api/visitor        -> accept single visitor record
  - GET  /api/visitors       -> return visitor array
  - DELETE /api/visitors     -> clear visitor store
  - GET  /api/visitors/export -> download visitors JSON
- Admin config:
  - GET /api/admin/config    -> read site config
  - POST /api/admin/config   -> update a section or replace config
- Comments:
  - POST /api/comments       -> submit comment (status: pending)
  - GET  /api/comments?status=pending|published -> list comments
  - PATCH /api/comments/:id  -> update (e.g., {status:'published'})
  - DELETE /api/comments/:id -> delete
  - POST /api/comments/bulk-delete -> { ids: [] }

Data persistence: JSON files under `server/data/` (visitors.json, comments.json, config.json).

Quick start:
1. cd server
2. npm install
3. npm run start

Server will run on port 3000 by default and serve static files from project root (so you can open http://localhost:3000/).

Notes:
- This prototype is for local/dev use only. For production, replace the storage with a proper DB and add authentication to admin endpoints.
- CORS is enabled for convenience; tune in a real deployment.
