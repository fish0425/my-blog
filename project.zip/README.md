# project

This repository contains a static frontend for a personal site and a small prototype backend in `server/` used for development.

To run the backend prototype:
1. cd server
2. npm install
3. npm start

Server will serve the site at http://localhost:3000 and provide simple APIs under /api/ (visitor, visitors, comments, admin config).
