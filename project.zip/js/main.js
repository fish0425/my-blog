(function () {
  function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[m]); }

  async function loadConfig() {
    try {
      const res = await fetch('/api/admin/config');
      if (res && res.ok) {
        const cfg = await res.json();
        localStorage.setItem('adminConfig', JSON.stringify(cfg));
        return cfg;
      }
    } catch (e) {}
    return JSON.parse(localStorage.getItem('adminConfig') || '{}');
  }

  function renderProfile(profile) {
    if (!profile) return;
    const titleEl = document.querySelector('.profile-title');
    const descEl = document.querySelector('.profile-desc');
    const tagsEl = document.querySelector('.profile-tags');
    if (titleEl && profile.title) titleEl.textContent = profile.title;
    if (descEl && profile.tagline) descEl.textContent = profile.tagline;
    if (tagsEl && Array.isArray(profile.tags)) {
      tagsEl.innerHTML = '';
      profile.tags.forEach(t => { const s=document.createElement('span'); s.className='tag'; s.textContent = t; tagsEl.appendChild(s); });
    }
  }

  function renderCerts(certs) {
    if (!Array.isArray(certs)) return;
    const container = document.querySelector('#certs .section-body');
    if (!container) return;
    container.innerHTML = '';
    certs.forEach(c => {
      const art = document.createElement('article'); art.className='neon-card cert-item';
      art.innerHTML = `
        <div class="cert-grid">
          <div class="cert-main">
            <h3>${escapeHtml(c.title)}</h3>
            <p class="cert-meta">${escapeHtml(c.meta||'')}</p>
            <p class="cert-desc">${escapeHtml(c.desc||'')}</p>
          </div>
          <div class="cert-action">${c.url?`<a href="${escapeHtml(c.url)}" target="_blank" rel="noopener noreferrer" class="btn-neon"><i class="fas fa-arrow-up-right-from-square"></i> 查看证书</a>`:''}</div>
        </div>`;
      container.appendChild(art);
    });
  }

  function renderProjects(projects) {
    if (!Array.isArray(projects)) return;
    const container = document.querySelector('#projects .section-body');
    if (!container) return;
    container.innerHTML = '';
    projects.forEach(p => {
      const art = document.createElement('article'); art.className='project-card neon-card';
      const metaHtml = (p.meta||[]).map(m=>`<li><i class="fas fa-check"></i> ${escapeHtml(m)}</li>`).join('');
      art.innerHTML = `<div class="project-header"><h3><i class="fas fa-server"></i> ${escapeHtml(p.title)}</h3><span class="project-tag">${escapeHtml(p.tag||'')}</span></div><p>${escapeHtml(p.desc||'')}</p><ul class="project-meta">${metaHtml}</ul>`;
      container.appendChild(art);
    });
  }

  function renderNotes(notes) {
    if (!Array.isArray(notes)) return;
    const container = document.querySelector('#notes .section-body');
    if (!container) return;
    container.innerHTML = '';
    notes.forEach(n => {
      const art = document.createElement('article'); art.className='neon-card note-item';
      art.innerHTML = `
        <div class="note-grid">
          <div class="note-main">
            <h3><i class="fas fa-terminal"></i> ${escapeHtml(n.title)}</h3>
            <p>${escapeHtml(n.excerpt||'')}</p>
          </div>
          <div class="note-meta">
            ${(n.tags||[]).map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join(' ')}
            ${n.url?`<div style="margin-top:8px"><a href="${escapeHtml(n.url)}" target="_blank" rel="noopener noreferrer" class="btn-neon"><i class="fas fa-arrow-up-right-from-square"></i> 阅读原文</a></div>`: ''}
          </div>
        </div>`;
      container.appendChild(art);
    });
  }

  function renderBlogs(blogs) {
    if (!Array.isArray(blogs)) return;
    const container = document.querySelector('#blog .section-body');
    if (!container) return;
    container.innerHTML = '';
    blogs.forEach(b => {
      const art = document.createElement('article'); art.className='blog-item neon-card';
      art.innerHTML = `
        <div class="blog-grid">
          <div class="blog-main">
            <h3>${escapeHtml(b.title)}</h3>
            <p>${escapeHtml(b.excerpt||'')}</p>
          </div>
          <div class="blog-action">
            ${b.url?`<a href="${escapeHtml(b.url)}" target="_blank" rel="noopener noreferrer" class="btn-neon"><i class="fas fa-arrow-up-right-from-square"></i> 前往博客</a>`:''}
            ${(b.tags||[]).length? `<div class="tags">${b.tags.map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join('')}</div>`: ''}
          </div>
        </div>`;
      container.appendChild(art);
    });
  }

  function renderHobbies(hobbies) {
    if (!Array.isArray(hobbies)) return;
    const container = document.querySelector('#hobbies .section-body');
    if (!container) return;
    container.innerHTML = '';
    hobbies.forEach(h => {
      const art = document.createElement('article'); art.className = 'neon-card hobby-item';
      art.innerHTML = `<h3><i class="fas fa-heart"></i> ${escapeHtml(h.title)} ${h.url?`<a href="${escapeHtml(h.url)}" target="_blank" rel="noopener noreferrer" class="small-link">↗</a>`:''}</h3><p>${escapeHtml(h.desc||'')}</p>${(h.tags||[]).length? `<div class="tags">${h.tags.map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join('')}</div>`: ''}`;
      container.appendChild(art);
    });
  }

  function renderTools(tools) {
    if (!Array.isArray(tools)) return;
    const container = document.querySelector('#tools .section-body');
    if (!container) return;
    container.innerHTML = '';
    tools.forEach(t => {
      const art = document.createElement('article'); art.className = 'neon-card tool-item';
      art.innerHTML = `<h3><i class="fas fa-wrench"></i> ${escapeHtml(t.title)} ${t.url?`<a href="${escapeHtml(t.url)}" target="_blank" rel="noopener noreferrer" class="small-link">↗</a>`:''}</h3><p>${escapeHtml(t.desc||'')}</p>${(t.tags||[]).length? `<div class="tags">${t.tags.map(tag=>`<span class="tag">${escapeHtml(tag)}</span>`).join('')}</div>`:''}`;
      container.appendChild(art);
    });
  }

  async function loadCommentsAndRender() {
    // fetch published comments
    try {
      const res = await fetch('/api/comments?status=published');
      if (res && res.ok) {
        const list = await res.json();
        const ul = document.getElementById('commentList');
        if (!ul) return;
        ul.innerHTML = '';
        list.slice().reverse().forEach(c => {
          const li = document.createElement('li'); li.className = 'comment-item';
          li.innerHTML = `<div class="comment-head"><strong>${escapeHtml(c.name)}</strong> <span class="comment-ts">${escapeHtml(new Date(c.ts).toLocaleString())}</span></div><div class="comment-body">${escapeHtml(c.content)}</div>`;
          ul.appendChild(li);
        });
        return;
      }
    } catch (e) {}
    // fallback: no-op
  }

  document.addEventListener('DOMContentLoaded', async () => {
    // If page opened via file://, rewrite /api fetches to http://localhost:3000 and show a banner instructing the user
    if (location.protocol === 'file:') {
      try {
        console.warn('[main] opened via file:// — proxying /api to http://localhost:3000');
        const base = 'http://localhost:3000';
        const originalFetch = window.fetch.bind(window);
        window.fetch = function (url, ...args) {
          try { if (typeof url === 'string' && url.startsWith('/api')) url = base + url; } catch (e) {}
          return originalFetch(url, ...args);
        };
        if (!document.getElementById('fileBannerMain')) {
          const b = document.createElement('div');
          b.id = 'fileBannerMain';
          b.style.position = 'fixed'; b.style.top = '0'; b.style.left = '0'; b.style.right = '0'; b.style.zIndex = 99990; b.style.padding = '8px 12px'; b.style.background = 'rgba(24,160,251,0.06)'; b.style.color = 'var(--text-main)';
          b.innerHTML = `页面通过 <code>file://</code> 打开；如出现 CORS/网络错误，请在项目目录运行 <code>node server/index.js</code>，然后用 <a href="http://localhost:3000/index.html" target="_blank">http://localhost:3000/index.html</a> 访问`;
          document.body.appendChild(b);
          document.documentElement.style.paddingTop = '36px';
        }
      } catch (e) {}
    }

    const cfg = await loadConfig();
    if (cfg.profile) renderProfile(cfg.profile);
    if (cfg.certs) renderCerts(cfg.certs);
    if (cfg.projects) renderProjects(cfg.projects);
    if (cfg.notes) renderNotes(cfg.notes);
    if (cfg.blogs) renderBlogs(cfg.blogs);

    // comments UI: hide if disabled
    const commentsCfg = cfg.comments || {};
    const commentForm = document.querySelector('.comment-form');
    const commentList = document.getElementById('commentList');
    if (commentForm) {
      if (commentsCfg.enabled === false) {
        commentForm.style.display = 'none';
      } else {
        commentForm.style.display = '';
        const submit = document.getElementById('commentSubmit');
        if (submit) submit.addEventListener('click', async (e) => {
          e.preventDefault();
          const name = (document.getElementById('commentName').value || '').trim() || '匿名';
          const content = (document.getElementById('commentContent').value || '').trim();
          if (!content) { alert('留言内容不能为空'); return; }
          const payload = { name, content, referrer: window.location.href };
          try {
            const res = await fetch('/api/comments', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            if (res && res.ok) {
              alert('留言提交成功，等待审核');
              document.getElementById('commentContent').value = '';
              loadCommentsAndRender();
              return;
            }
          } catch (e) {}
          // fallback: store local pending comment
          const list = JSON.parse(localStorage.getItem('localComments') || '[]');
          list.push({ id: Math.random().toString(36).slice(2), ts: new Date().toISOString(), name, content, status: 'pending', ip: 'local', ua: navigator.userAgent, referrer: window.location.href });
          localStorage.setItem('localComments', JSON.stringify(list));
          alert('留言已保存为本地待审（离线模式）');
        });
      }
    }

    // render hobbies/tools if configured
    if (cfg.hobbies) renderHobbies(cfg.hobbies);
    if (cfg.tools) renderTools(cfg.tools);

    // initial fetch published comments
    loadCommentsAndRender();

    // listen to changes from admin (storage events) and re-render
    window.addEventListener('storage', (e) => {
      if (!e.key) return;
      if (e.key === 'adminConfig' || e.key === 'adminConfigUpdatedAt') {
        try {
          const cfg2 = JSON.parse(localStorage.getItem('adminConfig') || '{}');
          if (cfg2.profile) renderProfile(cfg2.profile); else renderProfile({});
          if (cfg2.certs) renderCerts(cfg2.certs); else renderCerts([]);
          if (cfg2.projects) renderProjects(cfg2.projects); else renderProjects([]);
          if (cfg2.notes) renderNotes(cfg2.notes); else renderNotes([]);
          if (cfg2.blogs) renderBlogs(cfg2.blogs); else renderBlogs([]);
          if (cfg2.hobbies) renderHobbies(cfg2.hobbies); else renderHobbies([]);
          if (cfg2.tools) renderTools(cfg2.tools); else renderTools([]);
          // comments toggle
          const commentsCfg = cfg2.comments || {};
          const commentForm = document.querySelector('.comment-form');
          if (commentForm) {
            if (commentsCfg.enabled === false) commentForm.style.display = 'none'; else commentForm.style.display = '';
          }
        } catch (err) {
          // ignore
        }
      }
    });
  });
})();
