// Minimal particles config placeholder
// If particles.js is available, initialize a small, lightweight particle background
(function () {
  try {
    if (window.particlesJS && document.getElementById('particles-js')) {
      particlesJS('particles-js', {
        particles: {
          number: { value: 40, density: { enable: true, value_area: 800 } },
          color: { value: '#17a2b8' },
          shape: { type: 'circle' },
          opacity: { value: 0.5 },
          size: { value: 3 },
          line_linked: { enable: true, distance: 120, color: '#17a2b8', opacity: 0.2, width: 1 },
          move: { enable: true, speed: 1 }
        },
        interactivity: {
          detect_on: 'canvas',
          events: { onhover: { enable: true, mode: 'repulse' }, onclick: { enable: false } }
        },
        retina_detect: true
      });
    }
  } catch (e) {
    // fail silently if particles lib not available or init error
    console.warn('particles-config init failed', e);
  }
})();
