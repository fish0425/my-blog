(function () {
  // 小工具：安全转义
  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, function (m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }

  // Helper: safe fetch with timeout
  function fetchWithTimeout(url, options = {}, timeout = 4000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('timeout')), timeout);
      fetch(url, options).then(res => { clearTimeout(timer); resolve(res); }).catch(err => { clearTimeout(timer); reject(err); });
    });
  }

  // 侧边栏导航切换
  function initNav() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.admin-section');
    navLinks.forEach(btn => {
      btn.addEventListener('click', () => {
        navLinks.forEach(n => n.classList.remove('active'));
        sections.forEach(s => s.classList.remove('active'));
        btn.classList.add('active');
        const target = btn.dataset.target;
        const el = document.querySelector(target);
        if (el) el.classList.add('active');
      });
    });
  }

  // 访客数据：优先从后端拉取，如果不可用则回退到 localStorage
  async function loadVisitors(opts = {}) {
    // opts: { q: string, page: number, pageSize: number }
    const tbody = document.querySelector('#visitorTable tbody');
    const summary = document.getElementById('visitorSummary');
    tbody.innerHTML = '';
    try {
      const res = await fetchWithTimeout('/api/visitors', { method: 'GET' }, 3000);
      if (res && res.ok) {
        let log = await res.json();
        // filter by query
        if (opts.q) {
          const q = opts.q.toLowerCase();
          log = log.filter(e => (e.name||'').toLowerCase().includes(q) || (e.ip||'').includes(q) || (e.identity||'').includes(q));
        }
        if (summary) summary.textContent = `共 ${log.length} 条（来自后端）`;
        const rows = log.slice().reverse();
        // pagination
        const pageSize = opts.pageSize || 100;
        const page = opts.page || 1;
        const start = (page -1) * pageSize;
        const pageRows = rows.slice(start, start + pageSize);
        pageRows.forEach(entry => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td class="col-time">${escapeHtml(new Date(entry.ts).toLocaleString())}</td>
            <td class="col-name">${escapeHtml(entry.name)}</td>
            <td class="col-identity">${escapeHtml(entry.identity)}</td>
            <td class="col-ip">${escapeHtml(entry.ip)}</td>
            <td title="${escapeHtml(entry.ua || '')}" class="col-ua">${escapeHtml((entry.ua || '').slice(0, 60))}</td>
            <td class="col-ref">${escapeHtml(entry.referrer || '')}</td>
          `;
          tbody.appendChild(tr);
        });
        return;
      }
    } catch (e) {
      // 后端不可用，回退
    }

    // fallback: localStorage
    let log = JSON.parse(localStorage.getItem('visitorLog') || '[]');
    if (opts.q) {
      const q = opts.q.toLowerCase();
      log = log.filter(e => (e.name||'').toLowerCase().includes(q) || (e.ip||'').includes(q) || (e.identity||'').includes(q));
    }
    if (summary) summary.textContent = `共 ${log.length} 条（本地）`;
    const rows = log.slice().reverse();
    const pageSize = opts.pageSize || 100;
    const page = opts.page || 1;
    const start = (page -1) * pageSize;
    const pageRows = rows.slice(start, start + pageSize);
    pageRows.forEach(entry => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="col-time">${escapeHtml(new Date(entry.ts).toLocaleString())}</td>
        <td class="col-name">${escapeHtml(entry.name)}</td>
        <td class="col-identity">${escapeHtml(entry.identity)}</td>
        <td class="col-ip">${escapeHtml(entry.ip)}</td>
        <td title="${escapeHtml(entry.ua || '')}" class="col-ua">${escapeHtml((entry.ua || '').slice(0, 60))}</td>
        <td class="col-ref">${escapeHtml(entry.referrer || '')}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  // 导出：如果后端支持导出 API，优先使用；否则本地导出
  async function exportVisitors() {
    try {
      const res = await fetchWithTimeout('/api/visitors/export', { method: 'GET' }, 4000);
      if (res && res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = 'visitors_export.json'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
        return;
      }
    } catch (e) {}

    // fallback
    const data = localStorage.getItem('visitorLog') || '[]';
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'visitor_log.json'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }

  // 删除：优先调用后端 API，否则清空 localStorage
  async function clearVisitors() {
    if (!confirm('确定清空访客记录？此操作不可恢复。')) return;
    try {
      const res = await fetchWithTimeout('/api/visitors', { method: 'DELETE' }, 4000);
      if (res && (res.status === 200 || res.status === 204)) {
        await loadVisitors();
        return;
      }
    } catch (e) {}
    localStorage.removeItem('visitorLog');
    await loadVisitors();
  }

  // 管理配置：profile / intro / lists. 优先拉取后端配置
  async function loadConfig() {
    try {
      const res = await fetchWithTimeout('/api/admin/config', { method: 'GET' }, 3000);
      if (res && res.ok) {
        const cfg = await res.json();
        populateConfig(cfg, '（来自后端）');
        setBackendStatus('在线');
        return;
      }
    } catch (e) {
      setBackendStatus('离线');
    }
    // fallback
    const cfg = JSON.parse(localStorage.getItem('adminConfig') || '{}');
    populateConfig(cfg, '（本地）');
  }

  function setBackendStatus(text) {
    const el = document.getElementById('backendStatus');
    if (el) el.textContent = `后端：${text}`;
  }

  function populateConfig(cfg, note) {
    // profile
    if (cfg.profile) {
      const p = cfg.profile;
      if (p.status) document.getElementById('profileStatus').value = p.status;
      if (p.title) document.getElementById('profileTitle').value = p.title;
      if (p.tagline) document.getElementById('profileTagline').value = p.tagline;
      if (p.tags) document.getElementById('profileTags').value = p.tags.join(' ');
      // quick facts
      const qlist = document.getElementById('quickFactsList'); qlist.innerHTML = '';
      (p.quickFacts || []).forEach(f => addQuickFact(f));
    }

    // intro
    if (cfg.intro) {
      const i = cfg.intro;
      if (i.title) document.getElementById('introTitle').value = i.title;
      if (i.subtitle) document.getElementById('introSubtitle').value = i.subtitle;
      if (i.about) document.getElementById('introAboutText').value = i.about;
      const flist = document.getElementById('focusList'); flist.innerHTML = '';
      (i.focus || []).forEach(f => addFocusItem(f));
    }

    // lists
    if (cfg.certs) { const el = document.getElementById('certsList'); el.innerHTML = ''; cfg.certs.forEach(c => addCertItem(el, c)); }
    if (cfg.projects) { const el = document.getElementById('projectsList'); el.innerHTML = ''; cfg.projects.forEach(c => addProjectItem(el, c)); }
    if (cfg.notes) { const el = document.getElementById('notesList'); el.innerHTML = ''; cfg.notes.forEach(c => addNoteItem(el, c)); }
    if (cfg.blogs) { const el = document.getElementById('blogsList'); el.innerHTML = ''; cfg.blogs.forEach(c => addBlogItem(el, c)); }
    if (cfg.hobbies) { const el = document.getElementById('hobbiesList'); el.innerHTML = ''; cfg.hobbies.forEach(c => addHobbyItem(el, c)); }
    if (cfg.tools) { const el = document.getElementById('toolsList'); el.innerHTML = ''; cfg.tools.forEach(c => addToolItem(el, c)); }
    if (cfg.comments) {
      document.getElementById('commentsEnabled').checked = !!cfg.comments.enabled;
      if (cfg.comments.title) document.getElementById('commentsTitle').value = cfg.comments.title;
      if (cfg.comments.subtitle) document.getElementById('commentsSubtitle').value = cfg.comments.subtitle;
      if (cfg.comments.maxCount) document.getElementById('commentsMaxCount').value = cfg.comments.maxCount;
      document.getElementById('commentsShowVisitor').checked = !!cfg.comments.showVisitor;
      document.getElementById('commentsShowGreeting').checked = !!cfg.comments.showGreeting;
    }
  }

  // UI helpers: add quickfact / focus
  function addQuickFact(text = '') {
    const list = document.getElementById('quickFactsList');
    const div = document.createElement('div'); div.className = 'item-row';
    div.innerHTML = `<input type="text" class="input-inline" value="${escapeHtml(text)}" placeholder="小档案内容"><button class="btn-danger"><i class="fas fa-trash"></i> 删除</button>`;
    const del = div.querySelector('.btn-danger'); del.addEventListener('click', () => div.remove());
    list.appendChild(div);
  }
  function addFocusItem(text = '') {
    const list = document.getElementById('focusList');
    const div = document.createElement('div'); div.className = 'item-row';
    div.innerHTML = `<input type="text" class="input-inline" value="${escapeHtml(text)}" placeholder="关注方向"><button class="btn-danger"><i class="fas fa-trash"></i> 删除</button>`;
    const del = div.querySelector('.btn-danger'); del.addEventListener('click', () => div.remove());
    list.appendChild(div);
  }

  // Typed list item editors to match index.html layout
  function addCertItem(container, data = {}) {
    const div = document.createElement('div'); div.className = 'item-row item-cert';
    div.innerHTML = `
      <input class="input-inline" data-field="title" placeholder="证书名称" value="${escapeHtml(data.title || '')}">
      <input class="input-inline" data-field="meta" placeholder="颁发机构 · 年份" value="${escapeHtml(data.meta || '')}">
      <input class="input-inline" data-field="desc" placeholder="描述（可选）" value="${escapeHtml(data.desc || '')}">
      <input class="input-inline" data-field="url" placeholder="证书链接（可选）" value="${escapeHtml(data.url || '')}">
      <div style="display:flex;gap:8px;align-items:center;"><button class="btn-secondary btn-sm preview-btn">预览</button><button class="btn-danger"><i class="fas fa-trash"></i> 删除</button></div>
      <div class="item-preview" style="display:none;margin-top:8px;padding:8px;border-radius:8px;background:rgba(4,8,16,0.6);border:1px solid rgba(24,160,251,0.04);"></div>
    `;
    const del = div.querySelector('.btn-danger');
    del.addEventListener('click', () => div.remove());
    const previewBtn = div.querySelector('.preview-btn');
    const previewEl = div.querySelector('.item-preview');
    previewBtn.addEventListener('click', () => {
      const obj = { title: div.querySelector('[data-field="title"]').value.trim(), meta: div.querySelector('[data-field="meta"]').value.trim(), desc: div.querySelector('[data-field="desc"]').value.trim(), url: div.querySelector('[data-field="url"]').value.trim() };
      previewEl.innerHTML = renderItemPreview('cert', obj);
      previewEl.style.display = previewEl.style.display === 'none' ? 'block' : 'none';
    });
    container.appendChild(div);
  }

  function addBlogItem(container, data = {}) {
    const div = document.createElement('div'); div.className = 'item-row item-blog';
    div.innerHTML = `
      <input class="input-inline" data-field="title" placeholder="文章标题" value="${escapeHtml(data.title || '')}">
      <input class="input-inline" data-field="excerpt" placeholder="摘要" value="${escapeHtml(data.excerpt || '')}">
      <input class="input-inline" data-field="url" placeholder="链接（绝对或相对）" value="${escapeHtml(data.url || '')}">
      <div style="display:flex;gap:8px;align-items:center;"><button class="btn-secondary btn-sm preview-btn">预览</button><button class="btn-danger"><i class="fas fa-trash"></i> 删除</button></div>
      <div class="item-preview" style="display:none;margin-top:8px;padding:8px;border-radius:8px;background:rgba(4,8,16,0.6);border:1px solid rgba(24,160,251,0.04);"></div>
    `;
    const del = div.querySelector('.btn-danger');
    del.addEventListener('click', () => div.remove());
    const previewBtn = div.querySelector('.preview-btn');
    const previewEl = div.querySelector('.item-preview');
    previewBtn.addEventListener('click', () => {
      const obj = { title: div.querySelector('[data-field="title"]').value.trim(), excerpt: div.querySelector('[data-field="excerpt"]').value.trim(), url: div.querySelector('[data-field="url"]').value.trim() };
      previewEl.innerHTML = renderItemPreview('blog', obj);
      previewEl.style.display = previewEl.style.display === 'none' ? 'block' : 'none';
    });
    container.appendChild(div);
  }

  function addNoteItem(container, data = {}) {
    const div = document.createElement('div'); div.className = 'item-row item-note';
    div.innerHTML = `
      <input class="input-inline" data-field="title" placeholder="笔记标题" value="${escapeHtml(data.title || '')}">
      <input class="input-inline" data-field="excerpt" placeholder="摘要 / 简述" value="${escapeHtml(data.excerpt || '')}">
      <input class="input-inline" data-field="url" placeholder="链接（可选）" value="${escapeHtml(data.url || '')}">
      <input class="input-inline" data-field="tags" placeholder="标签（空格分隔）" value="${escapeHtml((data.tags || []).join ? (data.tags || []).join(' ') : (data.tags || ''))}">
      <div style="display:flex;gap:8px;align-items:center;"><button class="btn-secondary btn-sm preview-btn">预览</button><button class="btn-danger"><i class="fas fa-trash"></i> 删除</button></div>
      <div class="item-preview" style="display:none;margin-top:8px;padding:8px;border-radius:8px;background:rgba(4,8,16,0.6);border:1px solid rgba(24,160,251,0.04);grid-column:1/-1;"></div>
    `;
    const del = div.querySelector('.btn-danger');
    del.addEventListener('click', () => div.remove());
    const previewBtn = div.querySelector('.preview-btn');
    const previewEl = div.querySelector('.item-preview');
    previewBtn.addEventListener('click', () => {
      const obj = { title: div.querySelector('[data-field="title"]').value.trim(), excerpt: div.querySelector('[data-field="excerpt"]').value.trim(), tags: (div.querySelector('[data-field="tags"]')? div.querySelector('[data-field="tags"]').value.trim().split(/\s+/).filter(Boolean):[]) };
      previewEl.innerHTML = renderItemPreview('note', obj);
      previewEl.style.display = previewEl.style.display === 'none' ? 'block' : 'none';
    });
    container.appendChild(div);
  }

  function addProjectItem(container, data = {}) {
    const div = document.createElement('div'); div.className = 'item-row item-project';
    div.innerHTML = `
      <input class="input-inline" data-field="title" placeholder="项目标题" value="${escapeHtml(data.title || '')}">
      <input class="input-inline" data-field="tag" placeholder="标签（例如：长期维护）" value="${escapeHtml(data.tag || '')}">
      <input class="input-inline" data-field="desc" placeholder="简短描述" value="${escapeHtml(data.desc || '')}">
      <input class="input-inline" data-field="meta" placeholder="元信息（逗号分隔）" value="${escapeHtml((data.meta || []).join ? (data.meta || []).join(', ') : (data.meta || ''))}">
      <input class="input-inline" data-field="url" placeholder="链接/仓库 URL（可选）" value="${escapeHtml(data.url || '')}">
      <div style="display:flex;gap:8px;align-items:center;"><button class="btn-secondary btn-sm preview-btn">预览</button><button class="btn-danger"><i class="fas fa-trash"></i> 删除</button></div>
      <div class="item-preview" style="display:none;margin-top:8px;padding:8px;border-radius:8px;background:rgba(4,8,16,0.6);border:1px solid rgba(24,160,251,0.04);"></div>
    `;
    const del = div.querySelector('.btn-danger');
    del.addEventListener('click', () => div.remove());
    const previewBtn = div.querySelector('.preview-btn');
    const previewEl = div.querySelector('.item-preview');
    previewBtn.addEventListener('click', () => {
      const obj = { title: div.querySelector('[data-field="title"]').value.trim(), tag: div.querySelector('[data-field="tag"]').value.trim(), desc: div.querySelector('[data-field="desc"]').value.trim(), meta: (div.querySelector('[data-field="meta"]').value || '').split(/\s*,\s*/).filter(Boolean), url: div.querySelector('[data-field="url"]').value.trim() };
      previewEl.innerHTML = renderItemPreview('project', obj);
      previewEl.style.display = previewEl.style.display === 'none' ? 'block' : 'none';
    });
    container.appendChild(div);
  }

  function addHobbyItem(container, data = {}) {
    const div = document.createElement('div'); div.className = 'item-row item-hobby';
    div.innerHTML = `
      <input class="input-inline" data-field="title" placeholder="兴趣名称" value="${escapeHtml(data.title || '')}">
      <input class="input-inline" data-field="url" placeholder="相关链接（可选）" value="${escapeHtml(data.url || '')}">
      <input class="input-inline" data-field="desc" placeholder="简短描述（可选）" value="${escapeHtml(data.desc || '')}">
      <input class="input-inline" data-field="tags" placeholder="标签（空格分隔）" value="${escapeHtml((data.tags || []).join ? (data.tags || []).join(' ') : (data.tags || ''))}">
      <div style="display:flex;gap:8px;align-items:center;"><button class="btn-secondary btn-sm preview-btn">预览</button><button class="btn-danger"><i class="fas fa-trash"></i> 删除</button></div>
      <div class="item-preview" style="display:none;margin-top:8px;padding:8px;border-radius:8px;background:rgba(4,8,16,0.6);border:1px solid rgba(24,160,251,0.04);"></div>
    `;
    const del = div.querySelector('.btn-danger');
    del.addEventListener('click', () => div.remove());
    const previewBtn = div.querySelector('.preview-btn');
    const previewEl = div.querySelector('.item-preview');
    previewBtn.addEventListener('click', () => {
      const obj = { title: div.querySelector('[data-field="title"]').value.trim(), url: div.querySelector('[data-field="url"]').value.trim(), desc: div.querySelector('[data-field="desc"]').value.trim(), tags: (div.querySelector('[data-field="tags"]')? div.querySelector('[data-field="tags"]').value.trim().split(/\s+/).filter(Boolean):[]) };
      previewEl.innerHTML = renderItemPreview('hobby', obj);
      previewEl.style.display = previewEl.style.display === 'none' ? 'block' : 'none';
    });
    container.appendChild(div);
  }

  function addToolItem(container, data = {}) {
    const div = document.createElement('div'); div.className = 'item-row item-tool';
    div.innerHTML = `
      <input class="input-inline" data-field="title" placeholder="工具名称" value="${escapeHtml(data.title || '')}">
      <input class="input-inline" data-field="url" placeholder="链接（可选）" value="${escapeHtml(data.url || '')}">
      <input class="input-inline" data-field="desc" placeholder="简短说明" value="${escapeHtml(data.desc || '')}">
      <input class="input-inline" data-field="tags" placeholder="标签（空格分隔）" value="${escapeHtml((data.tags || []).join ? (data.tags || []).join(' ') : (data.tags || ''))}">
      <div style="display:flex;gap:8px;align-items:center;"><button class="btn-secondary btn-sm preview-btn">预览</button><button class="btn-danger"><i class="fas fa-trash"></i> 删除</button></div>
      <div class="item-preview" style="display:none;margin-top:8px;padding:8px;border-radius:8px;background:rgba(4,8,16,0.6);border:1px solid rgba(24,160,251,0.04);"></div>
    `;
    const del = div.querySelector('.btn-danger');
    del.addEventListener('click', () => div.remove());
    const previewBtn = div.querySelector('.preview-btn');
    const previewEl = div.querySelector('.item-preview');
    previewBtn.addEventListener('click', () => {
      const obj = { title: div.querySelector('[data-field="title"]').value.trim(), url: div.querySelector('[data-field="url"]').value.trim(), desc: div.querySelector('[data-field="desc"]').value.trim(), tags: (div.querySelector('[data-field="tags"]')? div.querySelector('[data-field="tags"]').value.trim().split(/\s+/).filter(Boolean):[]) };
      previewEl.innerHTML = renderItemPreview('tool', obj);
      previewEl.style.display = previewEl.style.display === 'none' ? 'block' : 'none';
    });
    container.appendChild(div);
  }

  function addBlogItem(container, data = {}) {
    const div = document.createElement('div'); div.className = 'item-row item-blog';
    div.innerHTML = `
      <input class="input-inline" data-field="title" placeholder="文章标题" value="${escapeHtml(data.title || '')}">
      <input class="input-inline" data-field="excerpt" placeholder="摘要" value="${escapeHtml(data.excerpt || '')}">
      <input class="input-inline" data-field="url" placeholder="链接（绝对或相对）" value="${escapeHtml(data.url || '')}">
      <input class="input-inline" data-field="tags" placeholder="标签（空格分隔）" value="${escapeHtml((data.tags || []).join ? (data.tags || []).join(' ') : (data.tags || ''))}">
      <button class="btn-danger"><i class="fas fa-trash"></i> 删除</button>
    `;
    const del = div.querySelector('.btn-danger'); del.addEventListener('click', () => div.remove());
    container.appendChild(div);
  }

  // collect list values (returns structured arrays for typed lists)
  function collectList(containerId) {
    const el = document.getElementById(containerId); if (!el) return [];
    const rows = Array.from(el.querySelectorAll('.item-row'));
        if (containerId === 'certsList') {
      return rows.map(r => ({ title: r.querySelector('[data-field="title"]').value.trim(), meta: r.querySelector('[data-field="meta"]').value.trim(), desc: r.querySelector('[data-field="desc"]').value.trim(), url: r.querySelector('[data-field="url"]')? r.querySelector('[data-field="url"]').value.trim(): '' })).filter(i => i.title);
    }
    if (containerId === 'blogsList') {
      return rows.map(r => ({ title: r.querySelector('[data-field="title"]').value.trim(), excerpt: r.querySelector('[data-field="excerpt"]').value.trim(), url: r.querySelector('[data-field="url"]').value.trim(), tags: (r.querySelector('[data-field="tags"]')? r.querySelector('[data-field="tags"]').value.trim().split(/\s+/).filter(Boolean):[]) })).filter(i => i.title);
    }
    if (containerId === 'notesList') {
      return rows.map(r => ({ title: r.querySelector('[data-field="title"]').value.trim(), excerpt: r.querySelector('[data-field="excerpt"]').value.trim(), url: r.querySelector('[data-field="url"]')? r.querySelector('[data-field="url"]').value.trim(): '', tags: (r.querySelector('[data-field="tags"]')? r.querySelector('[data-field="tags"]').value.trim().split(/\s+/).filter(Boolean):[]) })).filter(i => i.title);
    }
    if (containerId === 'projectsList') {
      return rows.map(r => ({ title: r.querySelector('[data-field="title"]').value.trim(), tag: r.querySelector('[data-field="tag"]').value.trim(), desc: r.querySelector('[data-field="desc"]').value.trim(), meta: (r.querySelector('[data-field="meta"]').value || '').split(/\s*,\s*/).filter(Boolean), url: r.querySelector('[data-field="url"]')? r.querySelector('[data-field="url"]').value.trim(): '' })).filter(i => i.title);
    }
    if (containerId === 'hobbiesList') {
      return rows.map(r => ({ title: r.querySelector('[data-field="title"]').value.trim(), url: r.querySelector('[data-field="url"]').value.trim(), desc: r.querySelector('[data-field="desc"]').value.trim(), tags: (r.querySelector('[data-field="tags"]')? r.querySelector('[data-field="tags"]').value.trim().split(/\s+/).filter(Boolean):[]) })).filter(i => i.title);
    }
    if (containerId === 'toolsList') {
      return rows.map(r => ({ title: r.querySelector('[data-field="title"]').value.trim(), url: r.querySelector('[data-field="url"]').value.trim(), desc: r.querySelector('[data-field="desc"]').value.trim(), tags: (r.querySelector('[data-field="tags"]')? r.querySelector('[data-field="tags"]').value.trim().split(/\s+/).filter(Boolean):[]) })).filter(i => i.title);
    }
    // default: simple string list
    return rows.map(r => (r.querySelector('input') ? r.querySelector('input').value.trim() : '')).filter(Boolean);
  }

  // save section to localStorage and try backend sync
  async function saveSection(section, data) {
    // save locally
    const cfg = JSON.parse(localStorage.getItem('adminConfig') || '{}');
    cfg[section] = data;
    localStorage.setItem('adminConfig', JSON.stringify(cfg));

    // try backend
    try {
      const res = await fetchWithTimeout('/api/admin/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ section, data }) }, 4000);
      if (res && res.ok) {
        const j = await res.json();
        if (j && j.ok && j.cfg) {
          // write full cfg returned by server and signal other tabs/pages
          localStorage.setItem('adminConfig', JSON.stringify(j.cfg));
          localStorage.setItem('adminConfigUpdatedAt', String(Date.now()));
        }
        setBackendStatus('在线');
      } else {
        setBackendStatus('离线');
      }
    } catch (e) {
      setBackendStatus('离线');
    }
  }

  // button handlers for adds and saves
  function initButtons() {
    document.getElementById('btnAddQuickFact').addEventListener('click', () => addQuickFact(''));
    document.getElementById('btnAddFocus').addEventListener('click', () => addFocusItem(''));
    document.getElementById('btnAddCert').addEventListener('click', () => addCertItem(document.getElementById('certsList'), {}));
    document.getElementById('btnAddProject').addEventListener('click', () => addProjectItem(document.getElementById('projectsList'), {}));
    document.getElementById('btnAddNote').addEventListener('click', () => addNoteItem(document.getElementById('notesList'), {}));
    document.getElementById('btnAddBlog').addEventListener('click', () => addBlogItem(document.getElementById('blogsList'), {}));
    document.getElementById('btnAddHobby').addEventListener('click', () => addHobbyItem(document.getElementById('hobbiesList'), {}));
    document.getElementById('btnAddTool').addEventListener('click', () => addToolItem(document.getElementById('toolsList'), {}));

    document.getElementById('btnSaveProfile').addEventListener('click', async () => {
      const profile = {
        status: document.getElementById('profileStatus').value,
        title: document.getElementById('profileTitle').value,
        tagline: document.getElementById('profileTagline').value,
        tags: (document.getElementById('profileTags').value || '').split(/\s+/).filter(Boolean),
        quickFacts: collectList('quickFactsList')
      };
      await saveSection('profile', profile);
      alert('已保存个人信息');
    });

    document.getElementById('btnSaveIntro').addEventListener('click', async () => {
      const intro = {
        title: document.getElementById('introTitle').value,
        subtitle: document.getElementById('introSubtitle').value,
        about: document.getElementById('introAboutText').value,
        focus: collectList('focusList')
      };
      await saveSection('intro', intro);
      alert('已保存简介');
    });

    document.getElementById('btnSaveCerts').addEventListener('click', async () => { await saveSection('certs', collectList('certsList')); alert('已保存证书'); });
    document.getElementById('btnSaveProjects').addEventListener('click', async () => { await saveSection('projects', collectList('projectsList')); alert('已保存项目'); });
    document.getElementById('btnSaveNotes').addEventListener('click', async () => { await saveSection('notes', collectList('notesList')); alert('已保存笔记'); });
    document.getElementById('btnSaveBlogs').addEventListener('click', async () => { await saveSection('blogs', collectList('blogsList')); alert('已保存博客'); });
    document.getElementById('btnSaveHobbies').addEventListener('click', async () => { await saveSection('hobbies', collectList('hobbiesList')); alert('已保存兴趣'); });
    document.getElementById('btnSaveTools').addEventListener('click', async () => { await saveSection('tools', collectList('toolsList')); alert('已保存工具'); });

    document.getElementById('btnSaveComments').addEventListener('click', async () => {
      const comments = {
        enabled: document.getElementById('commentsEnabled').checked,
        title: document.getElementById('commentsTitle').value,
        subtitle: document.getElementById('commentsSubtitle').value,
        maxCount: Number(document.getElementById('commentsMaxCount').value) || 20,
        showVisitor: document.getElementById('commentsShowVisitor').checked,
        showGreeting: document.getElementById('commentsShowGreeting').checked
      };
      await saveSection('comments', comments);
      alert('已保存留言设置');
    });

    // visitors controls
    const btnRefresh = document.getElementById('btnRefreshVisitors');
    const btnExport = document.getElementById('btnExportVisitors');
    const btnClear = document.getElementById('btnClearVisitors');
    if (btnRefresh) btnRefresh.addEventListener('click', () => loadVisitors({ q: document.getElementById('visitorSearch').value || '', pageSize: Number(document.getElementById('visitorPageSize').value || 100) }));
    if (btnExport) btnExport.addEventListener('click', exportVisitors);
    if (btnClear) btnClear.addEventListener('click', clearVisitors);

    const visitorSearch = document.getElementById('visitorSearch');
    const visitorPageSize = document.getElementById('visitorPageSize');
    if (visitorSearch) visitorSearch.addEventListener('input', () => loadVisitors({ q: visitorSearch.value || '', pageSize: Number(visitorPageSize.value || 100) }));
    if (visitorPageSize) visitorPageSize.addEventListener('change', () => loadVisitors({ q: visitorSearch.value || '', pageSize: Number(visitorPageSize.value || 100) }));

    // comment moderation handlers
    const btnRefreshC = document.getElementById('btnRefreshComments');
    const btnPubSel = document.getElementById('btnPublishSelected');
    const btnDelSel = document.getElementById('btnDeleteSelectedComments');
    const chkAll = document.getElementById('chkAllComments');
    if (btnRefreshC) btnRefreshC.addEventListener('click', loadComments);
    if (btnPubSel) btnPubSel.addEventListener('click', publishSelectedComments);
    if (btnDelSel) btnDelSel.addEventListener('click', deleteSelectedComments);
    if (chkAll) chkAll.addEventListener('change', (e) => {
      const checked = !!e.target.checked;
      document.querySelectorAll('#commentTable tbody input[type="checkbox"]').forEach(cb => cb.checked = checked);
    });
  }

  // comment management functions
  async function loadComments() {
    const tbody = document.querySelector('#commentTable tbody');
    const summary = document.getElementById('commentsSummary');
    tbody.innerHTML = '';
    try {
      const res = await fetchWithTimeout('/api/comments?status=pending', { method: 'GET' }, 3000);
      if (res && res.ok) {
        const list = await res.json();
        if (summary) summary.textContent = `待审 ${list.length} 条`;
        list.reverse().forEach(c => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td><input type="checkbox" data-id="${escapeHtml(c.id)}"></td>
            <td>${escapeHtml(new Date(c.ts).toLocaleString())}</td>
            <td>${escapeHtml(c.name)}</td>
            <td title="${escapeHtml(c.content)}">${escapeHtml(c.content.slice(0, 120))}</td>
            <td>${escapeHtml(c.ip)}</td>
            <td title="${escapeHtml(c.ua || '')}">${escapeHtml((c.ua || '').slice(0, 40))}</td>
            <td>${escapeHtml(c.referrer || '')}</td>
            <td>
              <button class="btn-primary btn-sm" data-action="publish" data-id="${escapeHtml(c.id)}">发布</button>
              <button class="btn-danger" data-action="delete" data-id="${escapeHtml(c.id)}"><i class="fas fa-trash"></i> 删除</button>
            </td>
          `;
          tbody.appendChild(tr);
        });

        // attach row-level handlers
        tbody.querySelectorAll('button[data-action="publish"]').forEach(b => b.addEventListener('click', async (e) => {
          const id = e.target.dataset.id;
          await publishComment(id);
          await loadComments();
        }));
        tbody.querySelectorAll('button[data-action="delete"]').forEach(b => b.addEventListener('click', async (e) => {
          const id = e.target.dataset.id;
          if (!confirm('确定删除该留言？')) return;
          await deleteComment(id);
          await loadComments();
        }));
        return;
      }
    } catch (e) {
      // fallback: local comments
    }

    // fallback to local
    const list = JSON.parse(localStorage.getItem('localComments') || '[]');
    if (summary) summary.textContent = `待审 ${list.length} 条（本地）`;
    list.reverse().forEach(c => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><input type="checkbox" data-id="${escapeHtml(c.id)}"></td>
        <td>${escapeHtml(new Date(c.ts).toLocaleString())}</td>
        <td>${escapeHtml(c.name)}</td>
        <td title="${escapeHtml(c.content)}">${escapeHtml(c.content.slice(0, 120))}</td>
        <td>${escapeHtml(c.ip)}</td>
        <td title="${escapeHtml(c.ua || '')}">${escapeHtml((c.ua || '').slice(0, 40))}</td>
        <td>${escapeHtml(c.referrer || '')}</td>
        <td>
          <button class="btn-primary btn-sm" data-action="publish" data-id="${escapeHtml(c.id)}">发布</button>
          <button class="btn-danger" data-action="delete" data-id="${escapeHtml(c.id)}"><i class="fas fa-trash"></i> 删除</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  async function publishComment(id) {
    try {
      const res = await fetchWithTimeout(`/api/comments/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'published' }) }, 3000);
      return res && res.ok;
    } catch (e) {
      // fallback local
      let list = JSON.parse(localStorage.getItem('localComments') || '[]');
      const idx = list.findIndex(c => c.id === id);
      if (idx !== -1) { list[idx].status = 'published'; localStorage.setItem('localComments', JSON.stringify(list)); return true; }
      return false;
    }
  }

  async function deleteComment(id) {
    try {
      const res = await fetchWithTimeout(`/api/comments/${id}`, { method: 'DELETE' }, 3000);
      return res && (res.status === 200 || res.status === 204);
    } catch (e) {
      // fallback
      let list = JSON.parse(localStorage.getItem('localComments') || '[]');
      list = list.filter(c => c.id !== id);
      localStorage.setItem('localComments', JSON.stringify(list));
      return true;
    }
  }

  async function publishSelectedComments() {
    const ids = Array.from(document.querySelectorAll('#commentTable tbody input[type="checkbox"]:checked')).map(cb => cb.dataset.id);
    if (!ids.length) { alert('未选择任何留言'); return; }
    if (!confirm(`发布 ${ids.length} 条留言？`)) return;
    for (const id of ids) await publishComment(id);
    await loadComments();
  }

  async function deleteSelectedComments() {
    const ids = Array.from(document.querySelectorAll('#commentTable tbody input[type="checkbox"]:checked')).map(cb => cb.dataset.id);
    if (!ids.length) { alert('未选择任何留言'); return; }
    if (!confirm(`删除 ${ids.length} 条留言？此操作不可恢复`)) return;
    try {
      const res = await fetchWithTimeout('/api/comments/bulk-delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids }) }, 4000);
      if (res && res.ok) { await loadComments(); return; }
    } catch (e) {}
    // fallback: delete one by one
    for (const id of ids) await deleteComment(id);
    await loadComments();
  }

  // 通用 message 处理器：拦截外部 postMessage 的 showAlertPopup，避免未处理错误
  function initMessageHandler() {
    window.addEventListener('message', (e) => {
      try {
        const d = e.data;
        if (!d || typeof d !== 'object') return;
        if (d.type === 'showAlertPopup') {
          const msg = d.message || d.msg || d.text || '提示';
          console.info('[admin] showAlertPopup:', msg);

          let container = document.getElementById('adminToastContainer');
          if (!container) {
            container = document.createElement('div');
            container.id = 'adminToastContainer';
            container.style.position = 'fixed';
            container.style.top = '16px';
            container.style.right = '16px';
            container.style.zIndex = 99999;
            document.body.appendChild(container);
          }

          const t = document.createElement('div');
          t.className = 'admin-toast';
          t.textContent = msg;
          t.style.background = 'rgba(24,160,251,0.06)';
          t.style.border = '1px solid rgba(24,160,251,0.14)';
          t.style.color = '#18a0fb';
          t.style.padding = '8px 12px';
          t.style.marginTop = '8px';
          t.style.borderRadius = '6px';
          t.style.boxShadow = '0 6px 16px rgba(2,6,23,0.4)';
          container.appendChild(t);

          setTimeout(() => {
            t.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            t.style.opacity = '0';
            t.style.transform = 'translateY(-8px)';
            setTimeout(() => t.remove(), 350);
          }, 3500);
        }
      } catch (err) {
        console.warn('[admin] message handler error', err);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    // if page opened via file://, show hint and transparently proxy /api calls to http://localhost:3000
    handleFileProtocolApiFallback();

    initNav();
    initButtons();
    initMessageHandler();
    initInputFixes();
    const vps = Number(document.getElementById('visitorPageSize')?.value || 100);
    loadVisitors({ q: '', pageSize: vps, page: 1 });
    loadConfig();
    loadComments();
  });
  // When the admin page is opened via file://, browsers block relative /api fetches.
  // Provide a helpful banner and rewrite fetch('/api/...') to http://localhost:3000/api/...
  function handleFileProtocolApiFallback() {
    if (location.protocol !== 'file:') return;
    console.warn('[admin] page opened via file:// — API requests will be proxied to http://localhost:3000');

    // banner
    if (!document.getElementById('adminFileBanner')) {
      const banner = document.createElement('div');
      banner.id = 'adminFileBanner';
      banner.style.position = 'fixed';
      banner.style.left = '0';
      banner.style.right = '0';
      banner.style.top = '0';
      banner.style.zIndex = 99998;
      banner.style.background = 'linear-gradient(90deg, rgba(255,200,0,0.06), rgba(255,120,0,0.03))';
      banner.style.borderBottom = '1px solid rgba(255,255,255,0.03)';
      banner.style.padding = '8px 12px';
      banner.style.display = 'flex';
      banner.style.justifyContent = 'space-between';
      banner.style.alignItems = 'center';
      banner.style.color = 'var(--text-main)';
      banner.innerHTML = `<div>本页面通过 <code>file://</code> 打开，浏览器会阻止对后端 <code>/api</code> 的相对请求。建议在项目目录运行 <code>node server/index.js</code>，然后用 <a href="http://localhost:3000/admin.html" target="_blank">http://localhost:3000/admin.html</a> 打开。</div>`;
      const btn = document.createElement('button');
      btn.className = 'btn-secondary';
      btn.textContent = '尝试使用 localhost:3000';
      btn.addEventListener('click', () => window.open('http://localhost:3000/admin.html', '_blank'));
      banner.appendChild(btn);
      document.body.appendChild(banner);
      // push content down a bit so banner doesn't overlap
      document.documentElement.style.paddingTop = '44px';
    }

    // rewrite fetch for relative API paths to localhost base
    try {
      const base = 'http://localhost:3000';
      const originalFetch = window.fetch.bind(window);
      window.fetch = function (url, ...args) {
        try {
          if (typeof url === 'string' && url.startsWith('/api')) url = base + url;
        } catch (e) {}
        return originalFetch(url, ...args);
      };
    } catch (e) { console.warn('[admin] failed to patch fetch', e); }
  }

  // Fix / diagnostic: ensure inputs are focusable and not accidentally disabled/blocked
  function initInputFixes() {
    // make sure all form controls are enabled and accept pointer events
    const controls = document.querySelectorAll('input,textarea,select,button');
    controls.forEach(c => {
      try { c.disabled = false; c.readOnly = c.readOnly && false; c.style.pointerEvents = 'auto'; } catch (e) {}
      // log attribute for debugging
      // console.debug('[admin] control', c.tagName, c.id || c.className, {disabled: c.disabled, readOnly: c.readOnly});
    });

    // ensure clicking an input focuses it (workaround when an invisible overlay steals clicks)
    document.addEventListener('click', (e) => {
      const target = e.target && (e.target.closest ? e.target.closest('input,textarea,select') : null);
      if (target) {
        try { if (target.disabled) target.disabled = false; if (target.readOnly) target.readOnly = false; target.focus(); } catch (err) {}
        return;
      }

      // more robust: find underlying form control when a covering element intercepted the click
      try {
        const x = e.clientX, y = e.clientY;
        if (typeof x === 'number' && typeof y === 'number') {
          const stack = document.elementsFromPoint(x, y);
          const underlying = stack.find(n => n && (n.tagName === 'INPUT' || n.tagName === 'TEXTAREA' || n.tagName === 'SELECT'));
          if (underlying) {
            console.warn('[admin] click intercepted by overlay:', stack[0] && { tag: stack[0].tagName, id: stack[0].id, class: stack[0].className, z: window.getComputedStyle(stack[0]).zIndex }, 'focusing underlying', underlying);
            try { underlying.disabled = false; underlying.readOnly = false; underlying.focus(); } catch (err) {}
            e.stopPropagation();
            e.preventDefault();
          }
        }
      } catch (err) {
        // ignore
      }
    }, true);

    // optional diagnostic: detect potential covering elements at load
    window.setTimeout(() => {
      const covers = Array.from(document.body.children).filter(el => {
        try {
          const st = window.getComputedStyle(el);
          return (st.position === 'fixed' || st.position === 'absolute') && Number((st.zIndex || 0)) > 50 && st.pointerEvents !== 'none' && (el.offsetWidth >= window.innerWidth * 0.6 || el.offsetHeight >= window.innerHeight * 0.6);
        } catch (e) { return false; }
      });
      if (covers.length) console.warn('[admin] potential covering elements detected:', covers.map(c => ({tag: c.tagName, id: c.id, class: c.className, z: window.getComputedStyle(c).zIndex}))); 
    }, 400);
  }
})();
